from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="predictor_tirex")

@app.get("/health")
def health():
    return {"status": "ok", "service": "predictor_tirex"}

class Echo(BaseModel):
    msg: str

@app.post("/echo")
def echo(payload: Echo):
    return {"service": "predictor_tirex", "echo": payload.msg}
