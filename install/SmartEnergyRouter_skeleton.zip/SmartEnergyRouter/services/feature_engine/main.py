from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="feature_engine")

@app.get("/health")
def health():
    return {"status": "ok", "service": "feature_engine"}

class Echo(BaseModel):
    msg: str

@app.post("/echo")
def echo(payload: Echo):
    return {"service": "feature_engine", "echo": payload.msg}
