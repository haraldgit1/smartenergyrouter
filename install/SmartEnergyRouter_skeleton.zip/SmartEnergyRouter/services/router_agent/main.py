from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="router_agent")

@app.get("/health")
def health():
    return {"status": "ok", "service": "router_agent"}

class Echo(BaseModel):
    msg: str

@app.post("/echo")
def echo(payload: Echo):
    return {"service": "router_agent", "echo": payload.msg}
