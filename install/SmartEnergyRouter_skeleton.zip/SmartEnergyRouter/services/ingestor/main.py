from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="ingestor")

@app.get("/health")
def health():
    return {"status": "ok", "service": "ingestor"}

class Echo(BaseModel):
    msg: str

@app.post("/echo")
def echo(payload: Echo):
    return {"service": "ingestor", "echo": payload.msg}
