// app/flows/page.tsx
import Link from "next/link";
import { getFlows } from "@/lib/api";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";

export const dynamic = "force-dynamic";

export default async function FlowsPage() {
  const flows = await getFlows(24);

  return (
    <div className="space-y-4">
      <div className="flex items-baseline justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold">Flows (letzte 24h)</h1>
          <p className="text-sm text-slate-400">
            Correlation-IDs über mehrere Services hinweg.
          </p>
        </div>
        <span className="text-xs text-slate-400">
          {flows.length} Flow(s)
        </span>
      </div>

      <div className="space-y-2">
        {flows.map((f) => (
          <Link key={f.flow_id} href={`/flows/${encodeURIComponent(f.flow_id)}`}>
            <Card className="border-slate-800 bg-slate-950/70 hover:border-sky-500/70 hover:bg-slate-900/70 transition-colors cursor-pointer">
              <CardContent className="p-3 text-xs flex flex-col gap-1">
                <div className="flex items-center justify-between gap-2">
                  <div className="font-mono text-[11px] text-slate-300 truncate max-w-[60%]">
                    {f.flow_id}
                  </div>
                  <Badge variant="outline">
                    {f.primary_device_id ?? "no device"}
                  </Badge>
                </div>
                <div className="flex flex-wrap items-center gap-2 text-[11px] text-slate-400">
                  <span>
                    {new Date(f.started_at).toLocaleTimeString("de-AT", {
                      hour12: false,
                    })}{" "}
                    –{" "}
                    {new Date(f.ended_at).toLocaleTimeString("de-AT", {
                      hour12: false,
                    })}
                  </span>
                  {f.duration_seconds !== null && (
                    <span>· {f.duration_seconds}s</span>
                  )}
                  <span>· {f.event_count} Events</span>
                  {f.services_involved && f.services_involved.length > 0 && (
                    <span className="truncate">
                      ·{" "}
                      {f.services_involved.filter(Boolean).join(" / ")}
                    </span>
                  )}
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
        {flows.length === 0 && (
          <div className="text-xs text-slate-500">
            Keine Flows im angegebenen Zeitraum gefunden.
          </div>
        )}
      </div>
    </div>
  );
}

