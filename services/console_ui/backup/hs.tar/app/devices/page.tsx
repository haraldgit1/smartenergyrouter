// app/devices/page.tsx
import Link from "next/link";
import { getDevices } from "@/lib/api";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";

export const dynamic = "force-dynamic";

export default async function DevicesPage() {
  const devices = await getDevices();

  return (
    <div className="space-y-4">
      <div className="flex items-baseline justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold">Devices</h1>
          <p className="text-sm text-slate-400">
            Übersicht aller bekannten Geräte inkl. letztem Event.
          </p>
        </div>
        <span className="text-xs text-slate-400">
          {devices.length} Device(s)
        </span>
      </div>

      <div className="grid gap-3 md:grid-cols-2">
        {devices.map((d) => (
          <Link key={d.device_id} href={`/devices/${d.device_id}`}>
            <Card className="h-full border-slate-800 bg-slate-950/70 hover:border-sky-500/60 hover:bg-slate-900/70 transition-colors cursor-pointer">
              <CardContent className="p-4 space-y-2">
                <div className="flex items-center justify-between gap-3">
                  <div className="space-y-1">
                    <div className="text-sm font-semibold">
                      {d.device_name}
                    </div>
                    <div className="text-xs text-slate-400">
                      ID: {d.device_id} ·{" "}
                      {d.device_type ?? "type: n/a"} ·{" "}
                      {d.device_location ?? "no location"}
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-1">
                    <Badge
                      variant={d.device_mode === "live" ? "default" : "outline"}
                    >
                      {d.device_mode ?? "n/a"}
                    </Badge>
                    <span className="text-[11px] text-slate-400">
                      {d.usecase_count} UseCase(s)
                    </span>
                  </div>
                </div>
                {d.last_event_type ? (
                  <div className="text-xs text-slate-300">
                    Letztes Event:{" "}
                    <span className="font-medium">{d.last_event_type}</span>{" "}
                    {d.last_event_ts && (
                      <span className="text-slate-400">
                        ·{" "}
                        {new Date(d.last_event_ts).toLocaleTimeString(
                          "de-AT",
                          { hour12: false },
                        )}
                      </span>
                    )}
                    {d.last_event_message && (
                      <div className="mt-1 text-[11px] text-slate-400 line-clamp-2">
                        {d.last_event_message}
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-xs text-slate-500">
                    Kein Event für dieses Device gefunden.
                  </div>
                )}
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}

